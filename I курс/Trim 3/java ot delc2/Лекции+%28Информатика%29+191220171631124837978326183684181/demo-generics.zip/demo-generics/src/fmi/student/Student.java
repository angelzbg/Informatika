package fmi.student;

public class Student {
    private String name;
    private int age;
    private String facNumber;

    public Student(String name, int age, String facNumber) {
        this.name = name;
        this.age = age;
        this.facNumber = facNumber;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getFacNumber() {
        return facNumber;
    }

    @Override
    public String toString() {
        return name + ", " + age + ", " + facNumber;
    }
}
