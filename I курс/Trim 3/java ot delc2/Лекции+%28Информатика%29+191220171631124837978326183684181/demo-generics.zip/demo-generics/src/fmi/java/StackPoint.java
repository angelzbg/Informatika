package fmi.java;

import java.util.ArrayList;
import java.util.List;

public class StackPoint<T> {
    private List stackElements;

    private int top;  // shows the top element

    public StackPoint() {
        stackElements = new ArrayList();
        top = -1;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void push(T x) {
        top++;
        stackElements.add(top, x);
    }

    public T top() {
        if (isEmpty()) {
            System.out.println("Stack empty");
            return null;
        }
        else
            return (T)stackElements.get(top);
    }

    public void pop() {
        if (isEmpty())
            System.out.println("Stack empty");
        else
            top--;
    }
}
