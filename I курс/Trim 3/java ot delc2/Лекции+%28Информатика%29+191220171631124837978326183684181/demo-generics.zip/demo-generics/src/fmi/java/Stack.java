package fmi.java;

public class Stack {
    private char[] stackElements;

    private int top;  // shows the top element

    public Stack(int n) {
        stackElements = new  char [n];
        top = -1;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void push(char x) {
        top++; stackElements[top] = x;
    }

    public char top() {
        if (isEmpty()) {
            System.out.println("Stack empty");
            return ' ';
        }
        else
            return stackElements [top];
    }

    public void pop() {
        if (isEmpty())
            System.out.println("Stack empty");
        else
            top--;
    }
}
