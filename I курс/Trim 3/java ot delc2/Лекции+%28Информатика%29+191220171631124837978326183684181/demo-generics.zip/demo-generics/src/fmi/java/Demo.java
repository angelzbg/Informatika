package fmi.java;

import fmi.student.Student;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by e.doychev on 1.6.2017 г..
 */
public class Demo {
    public static void main(String[] arg) {
        useNumberStack();
    }

    private static void useCharStack() {
        Stack stack = new Stack(100);

        System.out.println("Празен стек: " + stack.isEmpty());
        stack.push('Ф');
        stack.push('М');
        stack.push('И');
        System.out.println("Празен стек: " + stack.isEmpty());

        while (!stack.isEmpty()) {
            System.out.println(stack.top());
            stack.pop();
        }
        System.out.println("Празен стек: " + stack.isEmpty());
    }

/*
    private static void usePointStack() {
        StackPoint stack = new StackPoint(100);

        System.out.println("Празен стек: " + stack.isEmpty());

        Point p1 = new Point(10, 12);
        Point p2 = new Point(20, 31);
        Point p3 = new Point(30, 45);

        stack.push(p1);
        stack.push(p2);
        stack.push(p3);
        System.out.println("Празен стек: " + stack.isEmpty());

        Point lastPoint = new Point(20, 31);

        while (!stack.isEmpty()) {
            if (!stack.top().equals(lastPoint)) {
                System.out.println(stack.top());
            }

            stack.pop();
        }
        System.out.println("Празен стек: " + stack.isEmpty());
    }
*/

    private static void useStudentStack() {
        StackPoint<Student> stack = new StackPoint();

        System.out.println("Празен стек: " + stack.isEmpty());

        Student s1 = new Student("Иван", 20, "1234567890");
        Point p2 = new Point(20, 31);
        Point p3 = new Point(30, 45);

        stack.push(s1);
        //stack.push(p2);
        //stack.push(p3);
        System.out.println("Празен стек: " + stack.isEmpty());

        Point lastPoint = new Point(20, 31);

        while (!stack.isEmpty()) {
            System.out.println(stack.top());
            stack.pop();
        }
        System.out.println("Празен стек: " + stack.isEmpty());
    }

    private static void useNumberStack() {
        StackPoint<Number> stack = new StackPoint();
        System.out.println("Празен стек: " + stack.isEmpty());

        Student s1 = new Student("Иван", 20, "1234567890");
        Point p2 = new Point(20, 31);
        Point p3 = new Point(30, 45);

        stack.push(12);
        stack.push(12.4);
        //stack.push(p2);
        //stack.push(p3);
        System.out.println("Празен стек: " + stack.isEmpty());

        Point lastPoint = new Point(20, 31);

        while (!stack.isEmpty()) {
            System.out.println(stack.top());
            stack.pop();
        }
        System.out.println("Празен стек: " + stack.isEmpty());

        List<Student> students = new ArrayList();
        students.add(s1);
    }
}
