import animals.*;

public class OopDemo {

    public static void main(String[] args) {

        System.out.println("    ООП Демо    ");
        System.out.println("================");
        System.out.println();

        Animal fish = new Fish("Немо");
        fish.makeSound();
        System.out.println("Може ли да лети: " + fish.canFly());

        Animal bird = new Eagle("Феликс");
        bird.makeSound();
        System.out.println("Може ли да лети: " + bird.canFly());

        Human human = new Human("Иван");
        human.makeSound();
        human.walk();
        System.out.println("Може ли да лети: " + human.canFly());
    }
}
