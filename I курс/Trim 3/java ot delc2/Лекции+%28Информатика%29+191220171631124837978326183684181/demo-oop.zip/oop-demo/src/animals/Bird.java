package animals;

/**
 * Created by e.doychev on 25.5.2017 г..
 */
public class Bird extends Animal {
    public Bird(String name) {
        super(name);
    }

    @Override
    protected void printType() {
        System.out.println("Тип: Птица");
    }

    @Override
    public void makeSound() {
        System.out.println("Звук на птица");
    }

    @Override
    public final boolean canFly() {
        return true;
    }
}
