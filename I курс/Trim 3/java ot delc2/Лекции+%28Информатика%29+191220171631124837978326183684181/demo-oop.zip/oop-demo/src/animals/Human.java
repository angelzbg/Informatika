package animals;

/**
 * Created by e.doychev on 25.5.2017 г..
 */
public final class Human extends Animal {
    public Human(String name) {
        super(name);
    }

    @Override
    public void printType() {
        System.out.println("Тип: Човек");
    }

    @Override
    public boolean canFly() {
        return false;
    }

    public void walk() {
        System.out.println("Ходя");
    }
}
