package animals;

/**
 * Created by e.doychev on 25.5.2017 г..
 */
public abstract class Animal {

    private String name;

    public Animal(String name) {
        this.name = name;

        System.out.print("Създадено е ново животно с име " + getName() + ". ");
        printType();
    }

    protected void printType() {
        System.out.println("Тип: Неизвестен");
    }

    public void makeSound() {
        System.out.println("Звук: Няма звук");
    }

    public String getName() {
        return this.name;
    }

    public abstract boolean canFly();
}
