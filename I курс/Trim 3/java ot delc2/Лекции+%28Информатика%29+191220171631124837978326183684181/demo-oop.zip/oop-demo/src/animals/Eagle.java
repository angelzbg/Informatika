package animals;

/**
 * Created by e.doychev on 25.5.2017 г..
 */
public class Eagle extends Bird {
    public Eagle(String name) {
        super(name);
    }

    @Override
    public void printType() {
        System.out.println("Тип: Орел");
    }
}
