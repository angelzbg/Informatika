package animals;

/**
 * Created by e.doychev on 25.5.2017 г..
 */
public class Fish extends Animal {
    public Fish(String name) {
        super(name);
    }

    @Override
    protected void printType() {
        System.out.println("Тип: Риба");
    }

    @Override
    public boolean canFly() {
        return false;
    }
}
